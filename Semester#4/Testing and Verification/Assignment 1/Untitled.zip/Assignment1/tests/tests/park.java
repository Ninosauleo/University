package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import main.Car;

/**
 * Description: When a 5 meter free stretch of parking place is detected, 
 * the car moves to the beginning of the stretch and does a pre-programmed
 * reverse parallel parking maneuver. If no parking space is detected, the
 * car moves to the end of the street until a 5 meter of free parking space is found.
 * Pre-condition: There must be 5 meter of free parking space detected.
 * Post-condition: The car does reverse parallel parking maneuver.
 * Test-cases: 
 *       TC1. The car has detected free parking space.
 *       TC2. The car is already parked.
 *       TC3. Car doesn’t find free parking space.
 */

public class park {

	@Before
	public void setup(){
		
	}
	
	@Test
	public void carisParked() {
		Car car = new Car(null, null, 0, false, false); //*input* we should initialize before a car :)
		//car.park();
		Boolean result = car.whereIs().getParkingStatus();
		assertNotNull(result);
		assertEquals((car.whereIs().getParkingSpots() == true) ,result);
	}

}
